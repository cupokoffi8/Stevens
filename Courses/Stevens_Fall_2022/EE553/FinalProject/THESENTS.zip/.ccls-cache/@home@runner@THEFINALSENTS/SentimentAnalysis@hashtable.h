#include "wordentry.h"
#include "wordentry.cpp"
#include <iostream>
#include <list>
#include <string>
#include <vector>
using namespace std;

#ifndef HASHTABLE_H
#define HASHTABLE_H

class HashTable {

private:
  std::list<WordEntry> *hashTable;
  int size;

public:
  HashTable(int s);
  bool contains(const std::string &s);
  double getAverage(const std::string &s);
  void put(const std::string &s, int score);

private:
  int computeHash(const std::string &);
};
#endif // HASHTABLE_H