#include <cstdlib>
#include <fstream>
#include <iostream>
#include <vector> 
#include <string>
#include "word.cpp"
using namespace std;
 
string getMood(string message) {
  // declare a few needed variables for inputing the data
  string line;
  int score;

  // open input file
  ifstream myfile("sentiment.txt");
  if (myfile.fail()) {
    cout << "could not open file" << endl;
    exit(1);
  }

  // create hash table
  HashTable table(20071);


  //=================================================================
  // while (!myfile.eof()) {
  //   myfile >> score; // get score
  //   myfile.get();    // get blank space
  //   getline(myfile, line);
  //   int len = line.size();
  //   while (len > 0) { // identify all individual strings

  //     string sub;
  //     len = line.find(" ");
  //     if (len > 0) {
  //       sub = line.substr(0, len);
  //       line = line.substr(len + 1, line.size());
  //     } else {
  //       sub = line.substr(0, line.size() - 1);
  //     }

  //     table.put(sub, score); // insert string with the score
  //   }
  // }
  //==================================================================


  // after data is entered in hash function
  // prompt user for a new input

    // cout << "\033[35m" << "\nTell me about your day (Good, bad, etc.) " << "\033[0m" << "Press enter when done\n" << endl;
    // getline(cin, message);

    // used for calculating the average
    double sum = 0;
    int count = 0;

    double sentiment = 0.0;

    size_t len = message.size();
    // get each individual word from the input
    while (len != string::npos) {
      string sub;
      len = message.find(" ");
      if (len != string::npos) {
        sub = message.substr(0, len);
        message = message.substr(len + 1, message.size());
      } else {
        sub = message;
      }
      // calculate the score of each word
      sum += table.getAverage(sub);
      ++count;
    }

    sentiment = sum / count;

    string moodResult = ""; 

    if (message.size() > 0) {
      cout << "\nThe input has an average value of " << sentiment << endl;
      if (sentiment >= 3.0) {
        cout << "\033[32m" << "Positive Sentiment" << "\033[0m" << endl;
        moodResult = "Positive Sentiment"; 
      } else if (sentiment >= 2.0) {
        cout << "\033[33m" << "Somewhat Positive Sentiment" << "\033[0m" << endl;
        moodResult = "Positive Sentiment"; 
      } else if (sentiment >= 1.0) {
        cout << "\033[33m" << "Somewhat Negative Sentiment" << "\033[0m" << endl;
        moodResult = "Negative Sentiment"; 
      } else {
        cout << "\033[31m" << "Negative Sentiment" << "\033[0m" << endl;
        moodResult = "Negative Sentiment"; 
      }
      cout << endl;
    }
    return moodResult;
  };