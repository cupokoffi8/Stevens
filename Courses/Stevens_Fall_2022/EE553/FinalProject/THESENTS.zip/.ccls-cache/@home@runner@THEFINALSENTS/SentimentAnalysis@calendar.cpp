#pragma once
#include "energy.cpp"
#include "word.cpp"
#include <array>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
using namespace std;
using namespace std;

class Calendar {
public:
  array<string, 12> monthNames = {
      "January", "February", "March",     "April",   "May",      "June",
      "July",    "August",   "September", "October", "November", "December"};
  array<int, 12> monthDays = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

  int firstDayOfMonth(int cMonth, int cYear) {
    int firstDay = 0; // The first day of the year is assumed to be a Sunday

    // Add the number of days in each month up to the given month
    for (int i = 0; i < cMonth - 1; i++) {
      firstDay += monthDays[i];
    }

    // Adjust the number of days in February based on whether the year is a leap
    // year
    if (cYear % 4 == 0) {
      if (cYear % 100 == 0) {
        if (cYear % 400 == 0) {
          firstDay += 1;
        }
      } else {
        firstDay += 1;
      }
    }

    // Adjust the first day of the month based on the number of days that have
    // passed
    firstDay = firstDay % 7;

    return firstDay - 1;
  }

  Calendar() {}
  ~Calendar() {}
  bool getMood(string message) {
    // declare a few needed variables for inputing the data
    string line;
    int score;

    // open input file
    ifstream myfile;
    myfile.open("SentimentAnalysis/ref.txt");
    if (!myfile.is_open()) {
      cout << "could not open file" << endl;
      exit(1);
    }

    // create hash table
    HashTable table(200);

    while (!myfile.eof()) {
      myfile >> score; // get score
      myfile.get();    // get blank space
      getline(myfile, line);
      int len = line.size();
      while (len > 0) { // identify all individual strings

        string sub;
        len = line.find(" ");
        if (len > 0) {
          sub = line.substr(0, len);
          line = line.substr(len + 1, line.size());
        } else {
          sub = line.substr(0, line.size() - 1);
        }

        table.put(sub, score); // insert string with the score
      }
    }

    // after data is entered in hash function
    // prompt user for a new input

    // cout << "\033[35m" << "\nTell me about your day (Good, bad, etc.) "
    // << "\033[0m" << "Press enter when done\n" << endl; getline(cin,
    // message);

    // used for calculating the average
    double sum = 0;
    int count = 0;

    double sentiment = 0.0;

    size_t len = message.size();
    // get each individual word from the input
    while (len != string::npos) {
      string sub;
      len = message.find(" ");
      if (len != string::npos) {
        sub = message.substr(0, len);
        message = message.substr(len + 1, message.size());
      } else {
        sub = message;
      }
      // calculate the score of each word
      sum += table.getAverage(sub);
      ++count;
    }

    sentiment = sum / count;

    bool moodResult = false;

    if (message.size() > 0) {
      cout << "\nThe input has an average value of " << sentiment << endl;
      if (sentiment >= 3.0) {
        cout << "\033[32m"
             << "Positive Sentiment"
             << "\033[0m" << endl;
        moodResult = true;
      } else if (sentiment >= 2.0) {
        cout << "\033[33m"
             << "Somewhat Positive Sentiment"
             << "\033[0m" << endl;
        moodResult = true;
      } else if (sentiment >= 1.0) {
        cout << "\033[33m"
             << "Somewhat Negative Sentiment"
             << "\033[0m" << endl;
      } else {
        cout << "\033[31m"
             << "Negative Sentiment"
             << "\033[0m" << endl;
      }
      cout << endl;
    }
    return moodResult;
  };
  // Function to print the calendar for a given year
  void printCalendar() {
    // Prompt the user for the month and year
    cout << "Enter the month (1-12): ";
    int month;
    cin >> month;

    cout << "Enter the year: ";
    int year;
    cin >> year;

    // Adjust the number of days in February based on whether the year is a leap
    // year
    if (year % 4 == 0) {
      if (year % 100 == 0) {
        if (year % 400 == 0) {
          monthDays[1] = 29;
        }
      } else {
        monthDays[1] = 29;
      }
    }

    // Print the calendar for the given month and year
    cout << "\n------------------------------" << endl;
    cout << "       " << monthNames[month - 1] << " " << year << endl;
    cout << "------------------------------\n" << endl;

    cout << "\033[1;35m"
         << "   S   M   T   W  Th   F   S\033[0m" << endl;

    // Print the appropriate number of spaces before the first day of the month
    // For example, if the first day of the month is a Tuesday, we would print
    // one space

    int firstDay = firstDayOfMonth(month, year);

    int numSpaces = firstDay;
    while (numSpaces > 0) {
      cout << "    ";
      numSpaces--;
    }

    // Print the days of the month
    for (int day = 1; day <= monthDays[month - 1]; day++) {
      cout << setw(4) << day;

      firstDay++;
      if (firstDay == 7) {
        cout << endl;
        firstDay = 0;
      }
    }

    // Print the appropriate number of spaces after the last day of the month
    // For example, if the last day of the month is a Friday, we would print two
    // spaces
    numSpaces = 7 - firstDay;
    while (numSpaces > 0) {
      cout << "    ";
      numSpaces--;
    }
  }

  void addEnergyEvent(string date, string event) {
    energyEvents[date].push_back(event);
  }
  void addMoodEvent(string date, string event) {
    bool moodValue = getMood(event);
    string sentiment = "\033[32mPositive\033[0m";
    if (moodValue == false) {
      sentiment = "\033[31mNegative\033[0m";
    }
    sentiment = sentiment + " [" + event + "]";
    moodEvents[date].push_back(sentiment);
  }
  void removeEnergyEvent(string date, string event) {
    for (auto it = energyEvents[date].begin(); it != energyEvents[date].end();
         it++) {
      if (*it == event) {
        energyEvents[date].erase(it);
        break;
      }
    }
  }
  void removeMoodEvent(string date, string event) {
    for (auto it = moodEvents[date].begin(); it != moodEvents[date].end();
         it++) {
      if (*it == event) {
        moodEvents[date].erase(it);
        break;
      }
    }
  }
  void showEnergyEvents() {
    cout << "================" << endl;
    cout << "Energy events: " << endl;
    cout << "================\n" << endl;
    for (auto it = energyEvents.begin(); it != energyEvents.end(); it++) {
      cout << it->first << ": ";
      for (auto it2 = it->second.begin(); it2 != it->second.end(); it2++) {
        cout << *it2 << "/10, ";
      }
      cout << endl;
    }
  }
  void showMoodEvents() {
    cout << "================" << endl;
    cout << "Mood events: " << endl;
    cout << "================\n" << endl;
    for (auto it = moodEvents.begin(); it != moodEvents.end(); it++) {
      cout << it->first << ": ";
      for (auto it2 = it->second.begin(); it2 != it->second.end(); it2++) {
        cout << *it2 << ", ";
      }
      cout << endl;
    }
  }
  void showAllEvents() {
    cout << "================" << endl;
    cout << "Energy Events: " << endl;
    cout << "================\n" << endl;
    for (auto it = energyEvents.begin(); it != energyEvents.end(); it++) {
      cout << it->first << ": ";
      for (auto it2 = it->second.begin(); it2 != it->second.end(); it2++) {
        cout << *it2 << "/10, ";
      }
      cout << endl;
    }
    cout << "\n================" << endl;
    cout << "Mood Events: " << endl;
    cout << "================\n" << endl;
    for (auto it = moodEvents.begin(); it != moodEvents.end(); it++) {
      cout << it->first << ": ";
      for (auto it2 = it->second.begin(); it2 != it->second.end(); it2++) {
        cout << *it2 << ", ";
      }
      cout << endl;
    }
  }

private:
  map<string, vector<string>> energyEvents;
  map<string, vector<string>> moodEvents;
};