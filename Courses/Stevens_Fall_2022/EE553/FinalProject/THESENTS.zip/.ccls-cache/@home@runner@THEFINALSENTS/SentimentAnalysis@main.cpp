#include "calendar.cpp"
#include "energy.cpp"
#include "user.cpp"
#include <chrono>
#include <iostream>
#include <string>
#include <thread>
using namespace std;

// Prints text in a typing manner.
//
// text: The text to print.
// delay: The delay in milliseconds between each character.
void typeText(const string &text, int delay) {
  for (char c : text) {
    cout << c;
    cout.flush();
    this_thread::sleep_for(chrono::milliseconds(delay));
  }
}

int main() {
  // Create Calendar object
  Calendar calendar;
  // Introduce program and ask for user name

  cout << "\033[1m\033[35m"
       << "\n-------------------------\n"
       << "| Welcome to "
       << "\033[1m\033[36m"
       << "THE SENTS! "
       << "\033[1m\033[35m"
       << "|\n"
       << "-------------------------\n"
       << "\033[0m" << endl;

  // Create new user profile
  typeText("To begin, please enter your name: ", 100);
  string name;

  // User provides their name, which is then passed into the User class
  cout << "\033[32m";
  cin >> name;
  User user(name);
  cout << "\033[1m\033[37m"
       << "\n";
  typeText("{ Hi " + user.name + "! }", 100);
  cout << "\n"
       << "\033[0m" << endl;

  // A menu is created and given to the user to choose to add an event or show
  // trends
  while (1) {
    cout << "\033[1m\033[33m"
         << "\n==============================" << endl;
    cout << user.name << ", please select an option: " << endl;
    cout << "==============================\n"
         << "\033[0m" << endl;
    cout << "\033[34m"
         << "1. Add an energy entry" << endl;
    cout << "2. Add a mood entry" << endl;
    cout << "3. Add a goal" << endl;
    cout << "4. Remove a goal" << endl;
    cout << "5. Show All Energy Entries" << endl;
    cout << "6. Show All Mood Entries" << endl;
    cout << "7. Show All Entries" << endl;
    cout << "8. Print monthly calendar" << endl;
    cout << "Anything else to EXIT\n" << endl;
    cout << "\033[1m\033[33m"
         << "==============================\n"
         << "\033[0m" << endl;

    cout << "\033[31m"
         << "Option (Number): "
         << "\033[0m";

    int option;
    cout << "\033[32m";
    cin >> option;
    cout << "\033[0m"
         << "\n";

    if (option == 1) {
      typeText("Enter the date (MM/DD/YYYY): ", 100);
      string date;
      cout << "\033[32m";
      cin >> date;
      cout << "\033[0m";
      typeText("rank your energy on a scale of 1-10: ", 100);
      string energyEvent;
      cout << "\033[32m";
      cin >> energyEvent;
      calendar.addEnergyEvent(date, energyEvent);
      cout << "\033[2m"
           << "Energy event added!\n"
           << "\033[0m" << endl;
    } else if (option == 2) {
      typeText("Enter the date (MM/DD/YYYY): ", 100);
      string date;
      cout << "\033[32m";
      cin >> date;
      cout << "\033[0m";
      typeText("Describe your mood: ", 100);
      cout << endl;
      string moodEvent;
      cout << "\033[32m";
      cin.ignore();
      getline(cin, moodEvent);
      cout << "\033[0m";
      calendar.addMoodEvent(date, moodEvent);
    } else if (option == 3) {
      typeText("Enter a goal: ", 100);
      string goal;
      cout << "\033[32m";
      cin.ignore();
      getline(cin, goal);
      cout << "\033[2m";
      user.addGoal(goal);
      cout << "Goal added!\n" << endl;
      cout << "\033[0m";
    } else if (option == 4) {
      typeText("Enter a goal to remove: ", 100);
      string goalToRemove;
      cout << "\033[32m";
      cin.ignore();
      getline(cin, goalToRemove);
      cout << "\033[2m";
      user.removeGoal(goalToRemove);
      cout << "Goal removed!" << endl;
      cout << "\033[0m";
    } else if (option == 5) {
      calendar.showEnergyEvents();
    } else if (option == 6) {
      calendar.showMoodEvents();
    } else if (option == 7) {
      calendar.showAllEvents();
      cout << "\n";
      user.printGoals();
    } else if (option == 8) {
      calendar.printCalendar();
      cout << "\n";
    } else {
      cout << "Goodbye!" << endl;
      exit(1);
    }
  }
}