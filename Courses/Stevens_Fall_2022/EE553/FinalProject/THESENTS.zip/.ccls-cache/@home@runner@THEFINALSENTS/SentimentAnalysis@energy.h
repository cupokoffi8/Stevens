// header file for energy tracking
#ifndef ENERGY_H
#define ENERGY_H

#include <iostream>
#include <map>
#include <string>
#include <vector>
using namespace std;

class Energy {
public:
  Energy();
  ~Energy();
  void printEnergy();
  void addEnergyEvent(std::string date, std::string event);
  void removeEnergyEvent(std::string date, std::string event);
  void printAllEvents();

private:
  std::map<std::string, std::vector<std::string>> energyEvents;
};

#endif // ENERGY_H