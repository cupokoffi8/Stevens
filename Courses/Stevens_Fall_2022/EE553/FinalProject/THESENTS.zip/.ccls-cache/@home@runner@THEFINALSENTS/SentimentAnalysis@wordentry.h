#include <iostream>
#include <list>
#include <string>
#include <vector>
using namespace std;

#ifndef WORDENTRY_H
#define WORDENTRY_H

class WordEntry {

private:
  std::string word;
  int numAppearances;
  int totalScore;

public:
  WordEntry(const std::string &, int);
  void addNewAppearance(int s);
  const std::string &getWord();
  double getAverage();
};

#endif // WORDENTRY_H
