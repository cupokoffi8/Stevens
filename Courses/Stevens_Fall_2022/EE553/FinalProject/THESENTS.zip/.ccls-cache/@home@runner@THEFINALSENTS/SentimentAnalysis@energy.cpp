// cpp file for energy tracking
#pragma once
#include <iostream>
#include <map>
#include <string>
#include <vector>
using namespace std;

class Energy {
public:
  Energy() {}
  ~Energy() {}
  void printEnergy() { cout << "Energy" << endl; }
  void addEnergyEvent(string date, string event) {
    energyEvents[date].push_back(event);
  }
  void removeEnergyEvent(string date, string event) {
    for (auto it = energyEvents[date].begin(); it != energyEvents[date].end();
         it++) {
      if (*it == event) {
        energyEvents[date].erase(it);
        break;
      }
    }
  }
  void printAllEvents() {
    cout << "Energy Events" << endl;
    for (auto it = energyEvents.begin(); it != energyEvents.end(); it++) {
      cout << it->first << ": ";
      for (auto it2 = it->second.begin(); it2 != it->second.end(); it2++) {
        cout << *it2 << ", ";
      }
      cout << endl;
    }
  }

private:
  map<string, vector<string>> energyEvents;
};