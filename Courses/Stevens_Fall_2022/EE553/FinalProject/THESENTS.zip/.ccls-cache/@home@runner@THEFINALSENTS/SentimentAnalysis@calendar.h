// calendar.h
#ifndef CALENDAR_H
#define CALENDAR_H

#include "energy.cpp"
#include "mood.cpp"
#include <iostream>
#include <map>
#include <string>
#include <vector>
using namespace std;

class Calendar {
public:
  Calendar();
  ~Calendar();
  void printCalendar();
  void addEnergyEvent(std::string date, std::string event);
  void addMoodEvent(std::string date, std::string event);
  void removeEnergyEvent(std::string date, std::string event);
  void removeMoodEvent(std::string date, std::string event);
  void showEnergyEvents();
  void showMoodEvents();
  void showAllEvents();

private:
  std::map<std::string, std::vector<std::string>> energyEvents;
  std::map<std::string, std::vector<std::string>> moodEvents;
};

#endif // CALENDAR_H
