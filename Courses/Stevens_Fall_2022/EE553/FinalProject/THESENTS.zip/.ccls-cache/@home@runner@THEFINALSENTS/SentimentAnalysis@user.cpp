#pragma once
#include <iostream>
#include <string>
using namespace std;

class User {
public:
  string name;
  string goals[100];
  User(string sName) { this->name = sName; }
  ~User() {}
  void printUser() { cout << "User name: " << name << endl; }
  void setName(string name) { this->name = name; }
  void printGoals() {
    cout << "================" << endl;
    cout << "Goals: " << endl;
    cout << "================\n" << endl;
    for (int i = 0; i < 100; i++) {
      if (goals[i] != "") {
        cout << i + 1 << ".) " << goals[i] << endl;
      }
    }
  }
  void addGoal(string goal) {
    for (int i = 0; i < 100; i++) {
      if (goals[i] == "") {
        goals[i] = goal;
        break;
      }
    }
  }
  void removeGoal(string goal) {
    for (int i = 0; i < 100; i++) {
      if (goals[i] == goal) {
        goals[i] = "";
        break;
      }
    }
  }
  void showGoalProgress(string goal) {
    cout << "Goal progress: " << endl;
    for (int i = 0; i < 100; i++) {
      if (goals[i] == goal) {
        cout << goals[i] << endl;
        break;
      }
    }
  }
};