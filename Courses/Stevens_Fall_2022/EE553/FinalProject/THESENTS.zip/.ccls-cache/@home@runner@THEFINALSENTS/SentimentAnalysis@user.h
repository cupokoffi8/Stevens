#include <iostream>
#include <string>
using namespace std;

#ifndef USER_H
#define USER_H

class User {
public:
  User(string name);
  ~User();
  void printUser();
  void setName(std::string name);
  void printGoals();
  void addGoal(std::string goal);
  void removeGoal(std::string goal);
  void showGoalProgress(std::string goal);
  void showTrends();

private:
  std::string name;
  std::string goals[100];
};
#endif // USER_H

// import user to overload show trend functions for mood and energy