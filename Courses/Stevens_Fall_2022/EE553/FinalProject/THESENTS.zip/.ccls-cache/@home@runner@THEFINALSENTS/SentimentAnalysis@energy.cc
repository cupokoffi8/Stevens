// cpp file for energy tracking
#include "energy.h"
#include <iostream>
#include <string>
#include <vector>
#include <map> 
using namespace std; 

Energy::Energy()
{
}
Energy::~Energy()
{
}
void Energy::printEnergy()
{
    std::cout << "Energy" << std::endl;
}
void Energy::addEnergyEvent(std::string date, std::string event)
{
    energyEvents[date].push_back(event);
}
void Energy::removeEnergyEvent(std::string date, std::string event)
{
    for (auto it = energyEvents[date].begin(); it != energyEvents[date].end(); it++)
    {
        if (*it == event)
        {
            energyEvents[date].erase(it);
            break;
        }
    }
}
void Energy::printAllEvents()
{
    std::cout << "Energy Events" << std::endl;
    for (auto it = energyEvents.begin(); it != energyEvents.end(); it++)
    {
        std::cout << it->first << ": ";
        for (auto it2 = it->second.begin(); it2 != it->second.end(); it2++)
        {
            std::cout << *it2 << ", ";
        }
        std::cout << std::endl;
    }
}