The following are useful links to documentation and api's that will be implemented throughout the project.


## Documentation

Welcome to the documentation for the project. This is a work in progress and will be updated as the project progresses.

Sentiment Analysis allows for users to document and view trends regarding their mood and energy over time. This is done by using the Microsoft Cognitive Services API to analyze the user's text input and return a sentiment score. The sentiment score is then stored locally and displayed on a graph for the user to view. Energy is measured by the user's input on a 1 to 10 scale and is also stored locally and displayed on a graph for the user to view. The user can also view their mood and energy over time on a calendar.

How to interact with Sentiment Analysis:
- on the first use, enter a user name
- when prompted, or when desired, enter a mood and energy level using the following :
    * mood('mood')
    * energy('1-10')
- personal goals can be added and removed as well with the following command:
    * addGoal('goal') - adds a goal to the list
    * removeGoal('goal') - removes a goal from the list
- to view the various graphs, you can use the following commands:
    * showGoalProgress() - shows the progress of the goals
    * showTrends() - shows the trends of the mood and energy
    * showDailyProgress() - shows the progress of the mood and energy over the day
    * showWeeklyProgress() - shows the progress of the mood and energy over the week
    * showMonthlyProgress() - shows the progress of the mood and energy over the month
    * showYearlyProgress() - shows the progress of the mood and energy over the year