#include <iostream>

using namespace std;
// This part of creating typical class is commented because we are defining
// class in header file in addition to }; at the end in addition we need to
// indent function and indicate from which file it is coming e.g. std::cout. so
// we will use class name in .h file as: functionName(){}
class Complex {
  float real, img;

public:
  Complex() {
    // default constructor to initialize complex number to 0+0i
    // write your code here
    real = img = 0;
  }
  Complex(float r, float i) {
    // parameterized constructor to initialize complex number.
    // write your code here
    real = r;
    img = i;
  }

  void set(float r, float i) {
    // you can do set_real and another one for set_img
    // leave it empty, not required in the assignment
    // set mean change the current value
    real = r;
    img = i;
  }
  void display() {
    // display function print complex number as real +j (imaginary)
    // write your code here
    cout << real << "+" << img << "i" << endl;
  }

  void print() {
    // this function is read only print complex number as real imaginary with
    // space between two value write your code here
    cout << real << "+" << img << "i" << endl;
  }

  Complex negative() {
    // this function return the negative complex number
    // write your code here
  }

  Complex mul(Complex c1, Complex c2) {
    // this function perform complex multiplication and return the value
    Complex result;

    result.real = c1.real * c2.real;
    result.img = c1.img * c2.img;

    return result;
  }
  Complex add(Complex c1, Complex c2) {
    // this function perform complex addition and return the value
    Complex result;

    result.real = c1.real + c2.real;
    result.img = c1.img + c2.img;

    return result;
  }
  Complex sub(Complex c1, Complex c2) {
    // this function perform complex subtraction and return the value
    Complex result;

    result.real = c1.real - c2.real;
    result.img = c1.img - c2.img;

    return result;
  }

  // Complex operator+(Complex c1, Complex c2) {
  //   // Overload (+) operator
  //   // write your code here
  // }

  // ostream &operator<<(ostream &ostr, Complex c) {
  //   // Overload (<<) operator  to display complex number as real +j
  //   (imaginary)
  //   // write your code here
  // }
};

int main() {

  cout << "########" << endl;
  cout << "Problem Two" << endl;
  cout << "########" << endl;
  // Read only this part of the problem and check classComplex.cpp
  // modify Complex class to make this part run as described

  // define two complex number n1 and n2
  Complex n1(1, 2), n2(0.3, 4);
  // define complex number for different results
  Complex result1, result2, result3, result4, result5;
  //  addition
  result1.add(n1, n2);
  cout << "sum of two complex number is: ";
  result1.print(); // complex (real +j imaginary) print ==> real imaginary
  cout << endl;
  //  addition by overloading
  // result2 = n1 + n2; // overlaod (+) operation to add two complex number
  cout << "(use overload) sum of two complex number is: ";
  result2.print(); // complex (real +j imaginary) print ==> real imaginary
  cout << endl;
  //  multiplication
  result3.mul(n1, n2);
  cout << "multiplication of two complex number is: ";
  result3.display(); // complex (real +j imaginary) display ==> real +j
                     // (imaginary)
  cout << endl;
  //  negative function
  result4 = result1.negative();
  cout << "negative of complex number is: ";
  result4.print();
  cout << endl;
  //  subtraction
  result5.sub(n1, n2);
  cout << "subtraction for two complex number is: ";
  // cout << result5; // complex (real +j imaginary) overload operator "<<" ==>
  // real +j (imaginary)

  cout << "====[ end ]====" << endl;
  cout << "               " << endl;

  return 0;
}