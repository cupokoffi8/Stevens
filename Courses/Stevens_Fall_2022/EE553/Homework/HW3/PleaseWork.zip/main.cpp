#include <iostream>

using namespace std;
// This part of creating typical class is commented because we are defining
// class in header file in addition to }; at the end in addition we need to
// indent function and indicate from which file it is coming e.g. std::cout. so
// we will use class name in .h file as: functionName(){}
class Complex {
//Private:
    // float real, img;
public:
    float real, img;
    friend ostream& operator<<(ostream& ostr, Complex c);

//===================================================================

  Complex(float r = 0, float i = 0) {
    this->real = r;
    this->img = i;
  }

  void print() {
    cout<<real<<" + "<<img<<"i"<<endl;
  }

  void display() {
    cout<<real<<" + j"<<img<<endl;
  }

  Complex add(Complex c1, Complex c2) {
    // this function perform complex addition and return the value

    c1.real += c2.real;
    real = c1.real; 
    c1.img += c2.img; 
    img = c1.img; 

    return c1; 
  } 

  Complex sub(Complex c1, Complex c2) {
    // this function perform complex subtraction and return the value
    Complex result;

    result.real = c1.real - c2.real;
    real = result.real;
    result.img = c1.img - c2.img; 
    img = result.img; 

    return result;
  } 

  Complex mul(Complex c1, Complex c2) {
    // this function perform complex multiplication and return the value
     Complex Mult;
      Mult.real = c1.real*c2.real - c1.img*c2.img; 
      real = Mult.real; 
      Mult.img = c1.real*c2.img - c1.real*c2.img; 
      img = Mult.img; 
      return Mult;
  } 

  Complex negative() {
    // this function return the negative complex number
    Complex Mult;
      Mult.real = -1*real; 
      Mult.img = -1*img; 
      return Mult;
  } 
  
  Complex operator + (Complex c2) {
    // Overload (+) operator
          Complex temp;
          temp.real = real + c2.real; 
          temp.img = img + c2.img; 

          return temp;
  }

};

ostream& operator<<(ostream& ostr, Complex c)
{
  char pm;  
  float i = c.img; 
  if(c.img < 0) {pm = '-'; i*=-1;} else {pm = '+';}
    ostr << c.real << ' ' << pm << ' ' << i << 'i';  
    return ostr;
}

int main() {

  cout << "\n########" << endl;
  cout << "Problem Two" << endl;
  cout << "########\n" << endl;
  // Read only this part of the problem and check classComplex.cpp
  // modify Complex class to make this part run as described

  // define two complex number n1 and n2
  Complex n1(1, 2), n2(0.3, 4); 
  // define complex number for different results
  Complex result1, result2, result3, result4, result5;
  //  addition
  result1.add(n1, n2);
  cout << "sum of two complex number is: ";
  result1.print(); // complex (real +j imaginary) print ==> real imaginary
  cout << "\n" << endl;
  //  addition by overloading
  result2 = n1 + n2; // overlaod (+) operation to add two complex number
  cout << "(use overload) sum of two complex number is: ";
  result2.print(); // complex (real +j imaginary) print ==> real imaginary
  cout << "\n" << endl;
  //  multiplication
  result3.mul(n1, n2);
  cout << "multiplication of two complex number is: ";
  result3.display(); // complex (real +j imaginary) display ==> real +j
                     // (imaginary)
  cout << "\n" << endl;
  //  negative function
  result4 = result1.negative();
  cout << "negative of complex number is: ";
  result4.print();
  cout << "\n" << endl;
  //  subtraction
  result5.sub(n1, n2);
  cout << "subtraction for two complex number is: ";
  result5.print(); 
  cout << "\n" << endl; 
  cout << result5; 
  cout << "\n" << endl; 

  cout << "====[ end ]====" << endl;
  cout << "               " << endl;

  return 0;
}