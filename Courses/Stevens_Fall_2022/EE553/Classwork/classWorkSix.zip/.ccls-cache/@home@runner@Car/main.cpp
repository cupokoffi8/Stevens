#include "car.h"

int main() {

  Car c1, c2, c3;  
  
  c1.setMake("Honda"); c1.setModel(2006); c1.setColor("Green");
  c2.setMake("Toyota"); c2.setModel(2000); c2.setColor("Red");
  c3.setMake("BMW"); c3.setModel(2011); c3.setColor("Silver");
  
  cout << "\nHere is my garage: \n"; 
  cout << "=======================\n" << endl; 
  cout << c1; 
  cout << c2; 
  cout << c3; 
  cout << "\n======================\n" << endl; 

  cout << "Number of cars: ";  
  cout << Car::counter() << endl; 
}