#include <iostream>
#include <string>
using namespace std;

class Car {

private:
  string make;
  int model;
  string color;
  static int count; 

public:
  void setMake(string m);
  string getMake();

  void setModel(int m);
  int getModel();

  void setColor(string m);
  string getColor();

  Car() {}
  ~Car() {}

  static int counter() { return count; }

  friend ostream &operator<<(ostream &s, Car &b) {
    s << "[" << b.getColor() << " " << b.getModel() << " " << b.getMake() << "]" << endl;
    return s;
  }
}; 

int Car::count = 0;

void Car::setMake(string m) { make = m; count++; }

string Car::getMake() { return make; }

void Car::setModel(int m) { model = m; }

int Car::getModel() { return model; }

void Car::setColor(string m) { color = m; }

string Car::getColor() { return color; }