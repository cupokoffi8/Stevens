print('starting to load...')

import sys

name = 42


def func(): pass


class klass: pass


print('done loading.')
