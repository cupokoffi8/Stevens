def func():
    print("func of M")