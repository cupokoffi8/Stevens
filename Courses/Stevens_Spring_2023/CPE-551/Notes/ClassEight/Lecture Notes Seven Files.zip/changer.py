message = 'After editing'


def printer():
    print(message)
