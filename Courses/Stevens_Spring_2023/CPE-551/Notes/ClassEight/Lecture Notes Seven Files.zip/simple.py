print('hello')
spam = 1 # initialize variable