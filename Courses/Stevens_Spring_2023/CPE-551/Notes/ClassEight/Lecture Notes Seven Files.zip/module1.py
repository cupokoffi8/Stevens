# module1.py
def printer(x):
    print(x)

#A, B, C = 5, 6, 7
#print(A, B, C)

