def func():
    print("func of N")