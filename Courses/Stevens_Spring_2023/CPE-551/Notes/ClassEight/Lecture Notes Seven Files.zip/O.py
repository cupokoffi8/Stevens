import M
import N
M.func()
N.func()