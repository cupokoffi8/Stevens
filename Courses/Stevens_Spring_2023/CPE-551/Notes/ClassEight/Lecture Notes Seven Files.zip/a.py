import b

b.spam('gumby')
