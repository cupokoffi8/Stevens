# file b
def spam(text):
    print(text, 'spam')

