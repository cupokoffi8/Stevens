# unders.py
a, _b, c, _d = 1, 2, 3, 4