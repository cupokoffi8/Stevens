x=2
import mod3


print(x ,end=' ')
print(mod3.x)